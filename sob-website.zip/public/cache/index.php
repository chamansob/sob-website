<?php
require_once('../includes/initialize.php');
   header( 'Location: '.BASE_PATH.'public/admin' ) ;

?>