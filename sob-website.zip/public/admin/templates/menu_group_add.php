<h2>Add Menu Group</h2>
<form method="post" action="<?php echo site_url('menu_group.add'); ?>">
	<p>
		<label for="menu-group-title">Group Title</label>
		<input type="text" name="title" id="menu-group-title">
	</p>
</form>