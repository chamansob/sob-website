<?php
require_once(LIB_PATH . DS . 'database.php');

class User_mo extends user
{
}
