<?php
	require_once(LIB_PATH.DS.'database.php');
	use Intervention\Image\ImageManager;
	class Team_mo extends Team {
	}