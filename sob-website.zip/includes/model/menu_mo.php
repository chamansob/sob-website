<?php
require_once(LIB_PATH . DS . 'database.php');

class Menu_mo extends menu
{
}
