<?php
include('commonTrait.php');
//include('imageTrait.php');